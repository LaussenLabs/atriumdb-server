import ctypes

import numpy as np

from wal.codec.enums import ValueMode
from wal.codec.header_structure import WALHeaderStructure, get_header_structure_from_dict, \
    get_wal_header_struct_size

NANO = 10 ** 9

value_data_type_dict = {0: np.dtype("<f4"), 1: np.dtype("<f8"), 2: np.dtype("<i1"), 3: np.dtype("<i2"),
                        4: np.dtype("<i4"), 5: np.dtype("<i8")}
value_struct_char_dict = {0: 'f', 1: 'd', 2: 'b', 3: 'h', 4: 'i', 5: 'q'}
value_py_type_dict = {0: float, 1: float, 2: int, 3: int, 4: int, 5: int}
time_data_data_type = np.dtype('<i8')
value_metadata_data_type = np.dtype('<u4')
data_type_byte = np.uint8

header_size = ctypes.sizeof(WALHeaderStructure)

supported_versions = [1]


class WALData:
    def __init__(self, byte_arr=None):
        self.header = None
        self.data = None

        self.time_data = None
        self.server_time_data = None

        self.value_data = None
        self.message_sizes = None
        self.null_offsets = None

        self.byte_arr = byte_arr

    def __eq__(self, other):
        if self.byte_arr is not None and self._bytes_equal(self.byte_arr, other.byte_arr):
            return True
        if not self._bytes_equal(self.header, other.header):
            return False
        if self._numpy_not_equal(self.time_data, other.time_data):
            return False
        if self._numpy_not_equal(self.server_time_data, other.server_time_data):
            return False
        if self._numpy_not_equal(self.value_data, other.value_data):
            return False
        return True

    @classmethod
    def from_file(cls, path):
        return cls(byte_arr=np.fromfile(path, dtype=data_type_byte))

    @classmethod
    def from_interval_data(cls, header_dictionary, nominal_times, server_times, value_messages, messages_sizes=None,
                           null_offsets=None):
        assert header_dictionary['mode'] == ValueMode.INTERVALS.value
        assert len(value_messages.shape) == 2
        result = cls()
        result.header = get_header_structure_from_dict(header_dictionary)

        result.time_data = nominal_times
        result.server_time_data = server_times

        result.value_data = value_messages
        result.message_sizes = messages_sizes if messages_sizes is not None else result._guess_full_messages()
        result.null_offsets = null_offsets if null_offsets is not None else result._guess_no_offsets()

        return result

    @classmethod
    def from_time_value_data(cls, header_dictionary, nominal_times, server_times, values):
        assert header_dictionary['mode'] == ValueMode.TIME_VALUE_PAIRS.value
        result = cls()
        result.header = get_header_structure_from_dict(header_dictionary)

        result.time_data = nominal_times
        result.server_time_data = server_times

        result.value_data = values

        return result

    @staticmethod
    def _numpy_not_equal(arr_1, arr_2):
        if arr_1 is None or arr_2 is None:
            return arr_2 is not arr_1
        return not np.array_equal(arr_1, arr_2)

    @staticmethod
    def _bytes_equal(b_1, b_2):
        if b_1 is None or b_2 is None:
            return b_1 is b_2
        return bytearray(b_1) == bytearray(b_2)

    def interpret_byte_array(self):
        self.header = WALHeaderStructure.from_buffer(self.byte_arr)
        assert self.header.version in supported_versions

        if self.header.mode == ValueMode.TIME_VALUE_PAIRS.value:
            # Time-Value Pair
            self._interpret_time_value_pairs()

        elif self.header.mode == ValueMode.INTERVALS.value:
            # Intervals
            self._interpret_intervals()

        else:
            raise ValueError("{} mode not in {}".format(self.header.mode, list(ValueMode)))

    def prepare_byte_array(self):
        data_type = self._get_prepared_data_type()

        bytearray_size = get_wal_header_struct_size() + (data_type.itemsize * self.time_data.size)

        self.byte_arr = np.empty(bytearray_size, dtype=data_type_byte)
        self.byte_arr[:get_wal_header_struct_size()] = np.frombuffer(bytearray(self.header), dtype=data_type_byte)

        self.data = self.byte_arr[get_wal_header_struct_size():].view(dtype=data_type)

        self._prepare_data()

    def _get_prepared_data_type(self):
        if self.header.mode == ValueMode.TIME_VALUE_PAIRS.value:
            data_type = self._get_time_value_data_type()

        elif self.header.mode == ValueMode.INTERVALS.value:
            # Intervals
            data_type = self._get_interval_data_type()

        else:
            raise ValueError("{} mode not in {}".format(self.header.mode, list(ValueMode)))
        return data_type

    def _prepare_data(self):
        if self.header.mode == ValueMode.TIME_VALUE_PAIRS.value:
            self.data['nominal_time'] = self.time_data
            self.data['server_time'] = self.server_time_data
            self.data['value'] = self.value_data

        elif self.header.mode == ValueMode.INTERVALS.value:
            self.data['start_time_nominal'] = self.time_data
            self.data['start_time_server'] = self.server_time_data
            self.data['values'] = self.value_data

            self.data['num_values'] = self.message_sizes
            self.data['null_offset'] = self.null_offsets

        else:
            raise ValueError("{} mode not in {}".format(self.header.mode, list(ValueMode)))

    def _interpret_time_value_pairs(self):
        data_type = self._get_time_value_data_type()

        self.data = np.frombuffer(self.byte_arr[header_size:], dtype=data_type)

        self.time_data = self.data["nominal_time"]
        self.server_time_data = self.data["server_time"]

        self.value_data = self.data["value"]

    def _get_time_value_data_type(self):
        data_type = np.dtype([('nominal_time', time_data_data_type),
                              ('server_time', time_data_data_type),
                              ('value', value_data_type_dict[self.header.input_value_type])])
        return data_type

    def _interpret_intervals(self):
        data_type = self._get_interval_data_type()

        self.data = np.frombuffer(self.byte_arr[header_size:], dtype=data_type)

        self.time_data = self.data["start_time_nominal"]
        self.server_time_data = self.data["start_time_server"]

        self.value_data = self.data["values"]
        self.message_sizes = self.data["num_values"]
        self.null_offsets = self.data["null_offset"]

    def _get_interval_data_type(self):
        data_type = np.dtype([("start_time_nominal", time_data_data_type),
                              ("start_time_server", time_data_data_type),
                              ("num_values", value_metadata_data_type),
                              ("null_offset", value_metadata_data_type),
                              ("values", value_data_type_dict[self.header.input_value_type],
                               self.header.samples_per_message)])
        return data_type

    def _guess_full_messages(self):
        result = np.zeros(self.value_data.shape[0], dtype=value_metadata_data_type)
        result += self.value_data.shape[1]
        return result

    def _guess_no_offsets(self):
        result = np.zeros(self.value_data.shape[0], dtype=value_metadata_data_type)
        return result
